<?php
function usuarioOk($usuario, $contraseña) :bool {
   $patron=preg_match("/(([A-Za-z0-9]){8}+)/", $usuario);
   
   return ($patron && $contraseña==strrev($usuario));
  
}
function letraMasRepetida($frase){
$resultado="";
$max=0;
foreach (count_chars($frase,1) as $key => $value) {
        if ($value>$max) {
              $max=$value;
              $resultado=chr($key);

        }
  }
  return  $resultado;
}

function palabraMasRepetida($frase){
   
$resultado="";
$contador=str_word_count($frase,1);
$max=0;
  foreach ($contador as $key => $value) {
     if ($value>$max) {
         $max=$value;
         $resultado=chr($key);
      }
  }

  return $resultado;

   
}


?>
