<?php
function usuarioOk($usuario, $contraseña) :bool {
   $patron=preg_match("/(([A-Za-z0-9]){8}+)/", $usuario);
   
   return ($patron && $contraseña==strrev($usuario));
  
}
function letraMasRepetida($frase){
$resultado="";
$max=0;
foreach (count_chars($frase,1) as $key => $value) {
        if ($value>$max) {
              $max=$value;
              $resultado=chr($key);

        }
  }
  return  "La letra "."<b>".$resultado."</b>"." se ha repetido ".$max." veces";
}

function palabraMasRepetida($frase){
   
   $contador=str_word_count($frase,1);
   $array=[];
   
     foreach ($contador as $key => $value) {
       $array +=[ $value => mb_substr_count($frase,$value)];
     }
      
      arsort($array).'<br />';    
      max($array).'<br />';
   
      echo "La palabra "."<b>".key($array)."</b>"." se ha repetido ".max($array)." veces";
     //print_r(max())

   
}


?>
