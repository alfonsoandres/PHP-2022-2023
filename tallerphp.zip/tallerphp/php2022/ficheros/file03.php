<?php
$contenido = file_get_contents("https://www.iestetuan.es/cmsj");
echo $contenido;
