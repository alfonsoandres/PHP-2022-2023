<html>
<head>
<meta charset="UTF-8">
<title>ATAQUE</title>
</head>
<body>
<!-- Envio una orden sin el token !!!! -->
<a href="index.php?orden=Terminar" >Púlsarme </a>    
</body>
</html>