<?php
//Carga la tabla de bicis disponibles.
require_once('bicicletaElectrica.php');

function cargarBicis(): array
{
    $fich = @fopen('bicis.csv', 'r'); // abrimos el fichero para lectura
    if ($fich == false) {
        ("Error");
    }
    $tabla = [];
    while (($valor = fgetcsv($fich)) !== FALSE) {
        $bici = new BicicletaElectrica();
        $bici->id = $valor[0];
        $bici->coordx = $valor[1];
        $bici->coordy = $valor[2];
        $bici->bateria = $valor[3];
        $bici->operativa = $valor[4];
        $tabla[] = $bici;
    }

    return $tabla;
}
//mostrartablabicis – devuelve una cadena con la tabla html de bicis operativas.
function mostrartablabicis($tabla): string
{

    $cadena = "<table><tr><th>Id</th><th>CoorX</th><th>CoorY</th><th>Bateria</th></tr>";

    foreach ($tabla as $bici) {

        if ($bici->operativa == 1) {
            $cadena .= "<tr>";
            $cadena .= "<td>" . $bici->id . "</td>";
            $cadena .= "<td>" . $bici->coordx . "</td>";
            $cadena .= "<td>" . $bici->coordy . "</td>";
            $cadena .= "<td>" . $bici->bateria . "</td>";
            $cadena .= "</tr>";
        }
    }
    $cadena .= "</table>";

    return $cadena;
}
//bicimascercana – Devuelve la bici con menor distancia a las coordenadas de usuario.
function bicimascercana($tabla, $x, $y): mixed
{

    $bici = null;
    $distanciamin = PHP_INT_MAX;
    foreach ($tabla as $bici) {
        if ($bici->operativa == 1) {

            $longitud = $bici->distacia($x, $y);

            if ($longitud < $distanciamin) {
                $bicicerca = $bici;
                $distanciamin = $longitud;
            }
        }
    }



    return $bicicerca;
}
