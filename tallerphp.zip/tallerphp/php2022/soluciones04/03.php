<?php
  var_dump($_REQUEST);
  echo "<hr><pre>";
  print_r($_REQUEST);
  print "</pre>\n";
?>
