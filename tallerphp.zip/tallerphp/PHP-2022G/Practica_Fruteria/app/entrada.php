<form name="entrada" >
<h1>La Fruteria del siglo XXI</h1>

<h2>BIENVENIDO A LA NUESTRA FRUTERIA DEL SILO XXI</h2>
Introduzca su nombre de cliente:<input type="text" name="nombre">
<input type="submit" name="ordenBut" value="Entrar">
</form>