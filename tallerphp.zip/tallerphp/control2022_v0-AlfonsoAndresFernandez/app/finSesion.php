<form name="finpedido" method="POST">
<h1>Superado el numero de intentos</h1>
<h1>Su resultado final es de 

<?php echo $_SESSION['dinero']?>€</h1>
<?php session_destroy();?>

</form>