<?php
require_once ('dat/datos.php');
/*
 *  Devuelve true si el código del usuario y contraseña se 
 *  encuentra en la tabla de usuarios
 *  @param $login : Código de usuario
 *  @param $clave : Clave del usuario
 *  @return true o false
 */

function userOk($login,$clave):bool {
    global $usuarios;
    $boolean=false;
    
    foreach ($usuarios as $key => $value) {
        //print_r($value);
        //print_r($usuarios);
      

        if ($key == $login && $value[1]== $clave){
            $bolean=true;
            global $nombreAlumno;
            $nombreAlumno=$value[0];
            global $nombreProfesor;
            $nombreProfesor=$value[0];
            return $bolean;
        }else{
            $bolean=false;      
        }
    }
    return $boolean;

}

/**
 *  Devuelve el rol asociado al usuario
 *  @param $login: código de usuario
 *  @return ROL_ALUMNO o ROL_PROFESOR
 */
function getUserRol($login){
    global $usuarios;

    foreach ($usuarios as $key => $value) {
        
        if ($key == $login ){
 
            return $value[2];
        }else{
          
            return $value[2];
        }
    
    }
    return ROL_ALUMNO;
  
}

/**
 *  Muestra las notas del alumno indicado.
 *  @param $codigo: Código del usuario
 *  @return $devuelve una cadena con una tabla html con los resultados 
 */
function verNotasAlumno($codigo):String{
    $msg="";
    global $nombreModulos;
    global $notas;
    global $usuarios;
    global $nombreAlumno;

    $msg .= " Bienvenido/a alumno/a: ". $nombreAlumno;
    $msg .= "<table>";

    
    $msg .= "</table>";
    return $msg;
}

/**
 *  Muestra las notas de todos alumnos. 
 *  @param $codigo: Código del profesor
 *  @return $devuelve una cadena con una tabla html con los resultados 
 */
function verNotaTodas ($codigo): String {
    $msg="";
    global $nombreModulos;
    global $notas;
    global $usuarios;
    global $nombreProfesor;
    $msg .= " Bienvenido Profesor: ". $nombreProfesor;
    $msg .= "<table>";
    foreach ($nombreModulos as $key => $value) {


        print_r($nombreModulos=[]) ;
    }

    $msg .= "</table>";
    return $msg;
}