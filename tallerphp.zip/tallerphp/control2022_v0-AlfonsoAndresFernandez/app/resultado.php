<html>
<head>
<meta charset="UTF-8">
<link href="web/default.css" rel="stylesheet" type="text/css" />
<title>NOTAS</title>
</head>
<body>
<div id="container" style="width: 600px;">
<div id="header">
<h1>CONSULTA DE NOTAS</h1>
</div>

<div id="content">

<?= $contenido ?>

</div>
<button onclick="history.back();"> Volver </button>
</div>
</body>
</html>

