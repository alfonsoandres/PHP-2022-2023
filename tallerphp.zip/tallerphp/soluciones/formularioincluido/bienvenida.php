<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<link href="default.css" rel="stylesheet" type="text/css" />
</head>
<body>
	<div id="container" style="width: 380px;">
		<div id="header">
			<h1>BIENVENIDA</h1>
		</div>

		<div id="content">
		 Bienvenido <?=$nombre ?> al sistema.
		</div>

			
	</div>
</body>
</html>