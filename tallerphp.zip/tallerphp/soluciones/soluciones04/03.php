<?php
  var_dump($_REQUEST);
  print "<hr><pre>";
  print_r($_REQUEST);
  print "</pre>\n";
?>
