<?php
    function calSuma( $valor1, $valor2, &$resultado){
    $resultado = $valor1 + $valor2;
    }
    
    function calResta( $valor1, $valor2, &$resultado){
        $resultado = $valor1 - $valor2;
        
    }
    function calMulti( $valor1, $valor2, &$resultado){
        $resultado = $valor1 * $valor2;
        
    }
    function calDivi( $valor1, $valor2, &$resultado){
        $resultado = $valor1 / $valor2;
        
    }
    function calModulo( $valor1, $valor2, &$resultado){
        $resultado = $valor1 % $valor2;
        
    }
    function calPotencia( $valor1, $valor2, &$resultado){
        $resultado = $valor1 ** $valor2;
    }
 
?>