
<?php

$frase="alfonsoaa alfonso alfonso andres";

function palabraMasRepetida($frase){
   
      $resultado="";
      $contador=str_word_count($frase,1);
      $max=0;
      foreach ($contador as $key => $value) {
        
         
           if ($value>$max) {
               $max=$value;
               echo $resultado==chr($key);

            }
   

      }
}
palabraMasRepetida($frase);
?>