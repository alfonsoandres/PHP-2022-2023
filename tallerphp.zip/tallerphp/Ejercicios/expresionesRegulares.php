<?php
$texto = 'aaaaaaaaaaaaaaaaaaaaaaaaa';
$regex = '/^[a-zA-Z]((\.|_|-)?[a-zA-Z0-9]+){3}$/D';
if (preg_match($regex, $texto)) {
    echo 'El texto es válido';
} else {
    echo 'El texto NO es válido';
}
?>