<?php
$cookieDeportes=[];
$cookieEdad="";
$cookieGenero="";
?>
<html>
<head>
<meta charset="UTF-8">
<link href="default.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="container" style="width: 380px;">
<div id="header">
     <h1>SUS DATOS ALMACENADOS</h1>
</div>


<div id="content">
<fieldset> 
<form method="post">
<label>Edad</label> <input type="number" name="edad" value="<?=(isset($_COOKIE['edad']))?$_COOKIE['edad']:''?>" ><br> 
Género :<br>
        <label> Mujer </label>
        <input type="radio" name="genero"  value="Mujer" <?=(isset($_COOKIE['genero'] ) && $_COOKIE['genero'] =='Mujer')?"checked":"" ?> ><br> 
        <label> Hombre</label>
        <input type="radio" name="genero" value="Hombre"  <?=(isset($_COOKIE['genero'] ) && $_COOKIE['genero']=='Hombre')?"checked":"" ?>><br>
       
<label>Deportes</label><br>
        <select name="deportes[]" multiple="multiple" size="3">
     <option value="Futbol"      >Futbol</option>
     <option value="Tenis"       >Tenis</option>
     <option value="Ciclismo"    >Ciclismo</option>
     <option value="Otro"        >Otro</option>
    </select> 
    <br>
    <button name="confirmar" value="Confirmar"> Almacenar valores </button>
    <button name="eliminar" value="Eliminar"> Eliminar valores </button>
</form>
</fieldset>
</div>
</div>
</body>
</html>
<?php



if (isset($_COOKIE['genero'])) {

    $cookieGenero= $_COOKIE['genero'];
}
if (isset($_COOKIE['deportes[]'])) {
    $cookieDeportes= $_COOKIE['deportes'];
}
if (isset($_COOKIE['edad'])) {
    $cookieEdad= $_COOKIE['edad'];
}


if (isset($_REQUEST['confirmar'])) { 

    setcookie('edad',$_REQUEST['edad'],time() + (7*24*60*60));
    setcookie('genero',$_REQUEST['genero'],time() + (7*24*60*60));
    setcookie('deportes',$_REQUEST['deportes[]'],time() +( 7*24*60*60));

}
if (isset($_REQUEST['eliminar'])) { 
    header("Refresh:1");
    setcookie('edad',NULL,-100);
    setcookie('genero',NULL,-100);
    setcookie('deportes',NULL,-100);

}



?>