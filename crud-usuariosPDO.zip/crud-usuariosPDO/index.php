<?php
session_start();

include_once 'app/funciones.php';
include_once 'app/acciones.php';
include_once "app/layout/validarSesion.php";

if ($_SERVER['REQUEST_METHOD'] == "GET" ){
    var_dump($_GET['checkT']);
    if(!isset($_SESSION['sesionClave'])){
        if(isset($_GET['clave'])){
            if($_GET['clave'] == "12345"){
                $_SESSION['sesionClave'] = time();
                header("Location: index.php");
            }
        }
    }else{
$contenido="";
    if ( isset($_GET['orden'])){
        switch ($_GET['orden']) {
            case "Nuevo"    : accionAlta(); break;
            case "Borrar"   : accionBorrar   ($_GET['id']); break;
            case "Modificar": accionModificar($_GET['id']); break;
            case "Detalles" : accionDetalles ($_GET['id']);break;
            case "Terminar" : accionTerminar(); break;
            case "Incrementar":accionIncrementar($_GET['checkT']);break;
            case "Cambiar": accionCambiar(); break;
            }
        }else {
    if (  isset($_POST['orden'])){
         switch($_POST['orden']) {
             case "Nuevo"    : accionPostAlta(); break;
             case "Modificar": accionPostModificar(); break;
             case "Detalles":; // No hago nada
            
            }
        }
    }

$contenido .= mostrarDatos();

// Muestro la página principal
include_once "app/layout/principal.php";

}
}

