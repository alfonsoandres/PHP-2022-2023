<?php 
// FICHERO DE CONFURACIÓN DE LA APLICACIÓN
// Campos que se muestran en el formulario
define('CAMPOSVISIBLES',2);
// Fichero donde se guardan los datos
define('FILEUSER','dat/usuarios.txt');
// TIPO puede ser:
// txt  - Fichero de texto con un usuario en cada línea separados los campos por |
// csv  - Fichero de hoja de cálculo un usuario en cada línea separados por ,
// json - Fichero que guarda la tabla en formato JSON
define('TIPO','txt');

