<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VISTA PEDIDO</title>
</head>
<body>
    
<h1>Bienvenido usuario: <?=$user->nombre?> Has entrados<?= $x ?> veces en nuestra web</h1>
<h2>Esta es su lista de pedidos del cliente con código: <?=$user->cod_cliente ?></h2>


<?php 
   if (isset($tpedidos)){ ?>	
    	<table border=1><th>Producto</th><th>Precio</th></tr>
    		<?php foreach ($tpedidos as $pedidos ) { ?>
        	<tr>
        	<td><?=$pedidos->producto ?></td>
        	<td><?=$pedidos->precio   ?></td>
        	</tr>
   	 	 
    <?php } ?>
     </table>  
   <?php } ?>

</table>
</body>
</html>