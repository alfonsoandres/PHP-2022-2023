<?php
include_once "AccesoDatos.php";
include_once "Cliente.php";
include_once "Pedido.php";


$nombre = $_GET['nombre'];
$clave = $_GET['clave'];    


$db = AccesoDatos::initModelo();

$user = $db->checkearUsuario($nombre,$clave);

//var_dump($user);

$tpedidos = $db->obtenerListaPedidos($user->cod_cliente);

include_once "vistapedido.php";

?>